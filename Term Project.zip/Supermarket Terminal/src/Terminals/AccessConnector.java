package Terminals;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bharath
 */

// Class used to connect to the database
public class AccessConnector {
    
    private Connection con;
    private ResultSet rs;
    private Statement stmt;
//    private String DBName = "Supermarket_Database";
//    private String user = "user1";
//    private String pwd = "password";
//    private String dbURL = "jdbc:derby://localhost:1527/"+DBName+";create=true;user="+user+";password="+pwd+";";
    private String AccURL = "jdbc:ucanaccess://D://SUPERMARKETDB.accdb";
    
    
    
    


    //Constructor initializes the variables and loads the driver
    public void AccessConnector() throws ClassNotFoundException, InstantiationException, IllegalAccessException{
        
        con = null;
        rs = null;
        stmt = null;
        //Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    }
    
    //Method to open a new connection
    public boolean openConnection(){
        
        con = null;
        
        try{
            
            con = DriverManager.getConnection(AccURL); 
            
            if (con.isValid(0))
                
                return true;
            
            else{
                
                System.out.println("Not connected to database!!");
                return false;
            
            }
        }
        
        catch(SQLException sqle){
            //Generate "not connected" alert by returning false;
            return false;
        }
        

    }
    
    public ResultSet executeSelectQuery(String squery){
        
        //Making the result set null each time before it gets executed will ensure correct validation during the if-else 
        rs = null;
        stmt = null;
        
        try{
            if(con.isValid(0)){
                
                stmt = con.createStatement();
                rs = stmt.executeQuery(squery);
                
                if(rs.next() == false){
                    
                    System.out.println("Empty resultset!!");               
                }
                return rs;
            }
            
            else{
                
                System.out.println("Connection closed");
                this.openConnection();
                
                if(con.isValid(0))
                
                    System.out.println("Connection re-opened. Please try again");
                
                else
                
                    System.out.println("Connectivity problem!!");
                return null;
            }
                
        }
        
        catch(SQLException sqle){
            
            sqle.printStackTrace();
            return null;
        }
        
    }
    
    public boolean executeUpdateQuery(String uquery){
        
        stmt = null;
        boolean success = false;
        
        try{
            
            stmt = con.createStatement();
            if(stmt.executeUpdate(uquery) == 0);
                success = true;
        }
        catch(SQLException sqle){
            
            sqle.printStackTrace();
            return success;
        }
        return success;
    }
    
    //Method to close the connection
    public boolean closeConnection(){
        
        try{
            
            //Check if the connection is already closed
            if(con.isClosed())
                
                //If yes, simply return true
                return true;
            
            else{
                
                //If no, close the connection and return true
                con.close();
                return true;
            }
        }
        
        catch(SQLException sqle){
            
            sqle.printStackTrace();
            return false;
        }
        
    }
    
    public boolean isOpen() throws SQLException{
        try{
            if(con.isValid(0))
                return true;
            else
                return false;
        }
        catch(NullPointerException npe){
            Alert alert = new Alert(AlertType.ERROR);
            alert.setContentText("Database is not conncted!!!");
            alert.setHeaderText("DBMS ERROR!!");
            alert.showAndWait();
            return false;
        }
    }
    //Empty main()
    public static void main(String[] args){
        
    }
}
