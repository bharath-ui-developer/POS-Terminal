/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Terminals;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Bharath
 */
public class ManagerTerminal extends Application{
    
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    double width = screenSize.getWidth()-40;
    double height = screenSize.getHeight()-120;
    
    Stage primaryStage = new Stage();
    
    AccessConnector dbConnector = new AccessConnector();
    
    Alert alert = new Alert(AlertType.ERROR);
    
    @Override
    public void start(Stage stage) {
        
        primaryStage = stage;        
        loginScene();
    }
    private void loginScene(){
        
        BorderPane LoginPane = new BorderPane();
        
        HBox TopPane = new HBox();
        Label managerlabel = new Label("Manager's Terminal");
        managerlabel.setFont(Font.font("Times New Roman",FontWeight.EXTRA_BOLD,40));
        managerlabel.setAlignment(Pos.CENTER);
        TopPane.getChildren().add(managerlabel);
        TopPane.setAlignment(Pos.CENTER);
        LoginPane.setTop(TopPane);
        
        GridPane CenterPane = new GridPane();
        CenterPane.setPadding(new Insets(20,20,20,20));
        CenterPane.setHgap(20);
        CenterPane.setVgap(20);
        
        Label LoginLabel = new Label("Login:");
        LoginLabel.setFont(Font.font("Verdana",FontWeight.BOLD,20));
        LoginLabel.setAlignment(Pos.CENTER_LEFT);
        CenterPane.add(LoginLabel, 0, 0);
        
        Label UserNameLabel = new Label("Username: ");
        UserNameLabel.setAlignment(Pos.CENTER_LEFT);
        UserNameLabel.setFont(Font.font("Verdana",FontWeight.MEDIUM,14));
        CenterPane.add(UserNameLabel, 0, 1);
        
        TextField UserNameField = new TextField("mgr");
        UserNameField.setFont(Font.font("Times New Roman", FontWeight.SEMI_BOLD, 14));
        CenterPane.add(UserNameField, 1, 1);
        
        Label PasswordLabel = new Label("Password:");
        PasswordLabel.setFont(Font.font("Verdana",FontWeight.MEDIUM,14));
        CenterPane.add(PasswordLabel, 0, 2);
        
        PasswordField pswdfld = new PasswordField();
        pswdfld.setFont(Font.font("Times New Roman", FontWeight.MEDIUM, 14));
        CenterPane.add(pswdfld, 1, 2);
        
        Button LoginButton = new Button("Login");
        LoginButton.setAlignment(Pos.CENTER);
        CenterPane.add(LoginButton, 2, 2);
        
        Label hint = new Label("For TESTing purposes:\n username: mgr\npassword: mgrmgr");
        hint.setFont(Font.font("Verdana",30));
        hint.setTextFill(Color.RED);
        CenterPane.add(hint, 2, 4);
        
        CenterPane.setAlignment(Pos.CENTER);
        
        LoginPane.setCenter(CenterPane);
        LoginPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Scene LoginScene = new Scene(LoginPane,width,height);
        
        primaryStage.setScene(LoginScene);
        primaryStage.setTitle("Manager's Terminal");
        primaryStage.show();
        
        LoginButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            ResultSet LoginRS;
            
            @Override
            public void handle(MouseEvent event) {
                
                if(UserNameField.getText().compareTo("mgr") == 0){
                    
                    dbConnector.openConnection();
                    LoginRS = dbConnector.executeSelectQuery("SELECT EMP_PASSWORD FROM STORE_LOGIN_DETAILS WHERE EMP_USER_NAME = 'mgr'");
                    
                    try{
                        
                        //Check if passwords match
                        if(pswdfld.getText().compareTo(LoginRS.getString("EMP_PASSWORD")) == 0){
                            
                            //Empty the TextField s
                            pswdfld.clear();
                            UserNameField.clear();
                            dbConnector.closeConnection();
                            //proceed with manager tools scene
                            managerTools();
                        }
                    
                        else{
                        
                            //generate password mismatch error
                            alert.setAlertType(AlertType.WARNING);
                            alert.setHeaderText("CREDENTIAL WARNING!!");
                            alert.setContentText("Only managers are allowed to login!!");
                            alert.showAndWait();
                            
                            //Empty the TextField s
                            pswdfld.clear();
                        }
                    }
                    catch(SQLException sqle){
                        
                        System.err.println("Manager login exception!!!");
                        sqle.printStackTrace();
                    }
                }
                
                else{
                        
                    //generate manager only alert
                    alert.setAlertType(AlertType.ERROR);
                    alert.setHeaderText("INVALID PASSWORD!!");
                    alert.setContentText("The password is wrong!!");
                    alert.showAndWait();
                }
                
            }
        });
    }
    
    public void managerTools(){
        
        BorderPane MainPane = new BorderPane();
        
        HBox TopPane = new HBox();
        
        Label WelcomeLabel = new Label("WELCOME MANAGER!!");
        WelcomeLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 40));
        TopPane.getChildren().add(WelcomeLabel);
        TopPane.setAlignment(Pos.CENTER);
        MainPane.setTop(TopPane);
        
        GridPane CenterPane = new GridPane();
        CenterPane.setHgap(20);
        CenterPane.setVgap(20);
        CenterPane.setAlignment(Pos.CENTER);
        
        Font Verdana20 = new Font("Verdana", 20);
        
        Button MgEmpsBtn = new Button("Manage Employees");
        MgEmpsBtn.setFont(Verdana20);
        CenterPane.add(MgEmpsBtn, 0, 0);
        
        Button MgStrInvntryBtn = new Button("Manage Store Inventory");
        MgStrInvntryBtn.setFont(Verdana20);
        CenterPane.add(MgStrInvntryBtn, 0, 1);
                
        Button LogoutButton = new Button("Logout");
        LogoutButton.setFont(Verdana20);
        LogoutButton.setTextFill(Color.GREEN);
        CenterPane.add(LogoutButton, 0, 2);
        
        MainPane.setCenter(CenterPane);
        MainPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Scene ManagerToolsScene = new Scene(MainPane,width,height);
        primaryStage.setScene(ManagerToolsScene);
        
        primaryStage.show();
        
        MgEmpsBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                manageEmpScene();
            }        
        });
        
        MgStrInvntryBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                manageInventoryScene();
            }
        });
        
        LogoutButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                loginScene();
            }
        });
    }
    
    private void manageEmpScene(){
        
        BorderPane MainPane = new BorderPane();
        
        Font Verdana20 = new Font("Verdana", 20); 
        
        HBox TopPane = new HBox();
        
        Label PaneLabel = new Label("Manage Employees");
        PaneLabel.setFont(Font.font("Times New Roman",FontWeight.BOLD, 40));
        TopPane.getChildren().add(PaneLabel);
        TopPane.setAlignment(Pos.CENTER);
        
        MainPane.setTop(TopPane);
        
        GridPane CenterPane = new GridPane();
        CenterPane.setHgap(20);
        CenterPane.setVgap(20);
        CenterPane.setAlignment(Pos.CENTER);
        
        Button MgEmpSalBtn = new Button("Manage Employee salary/bonus");
        MgEmpSalBtn.setFont(Verdana20);
        CenterPane.add(MgEmpSalBtn, 0, 0);
        
        Button MgEmpDtlsBtn = new Button("Manage Employee details");
        MgEmpDtlsBtn.setFont(Verdana20);
        CenterPane.add(MgEmpDtlsBtn, 0, 1);
        
        Button AddEmpBtn = new Button("Add a new Employee");
        AddEmpBtn.setFont(Verdana20);
        CenterPane.add(AddEmpBtn, 0, 2);
        
        Button RemEmpBtn = new Button("Remove an Employee");
        RemEmpBtn.setFont(Verdana20);
        CenterPane.add(RemEmpBtn, 0, 2);
        
        Button LogoutButton = new Button("Logout");
        LogoutButton.setFont(Verdana20);
        LogoutButton.setTextFill(Color.GREEN);
        CenterPane.add(LogoutButton, 1, 3);
        
        MainPane.setCenter(CenterPane);
        MainPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Scene manageEmpScene = new Scene(MainPane,width,height); 
        
        primaryStage.setScene(manageEmpScene);
        primaryStage.show();
        
        MgEmpSalBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                manageEmployeeSalOrBonusScene();
                
            }
        });
        
        MgEmpDtlsBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                //manageEmployeeDetailsScene();
            }
        });
        
        AddEmpBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                //addEmployeeScene();
                
            }
        });
        
        RemEmpBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                //removeEmployeeScene();
            }
            
            
        });
        
        LogoutButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                loginScene();
            }
        });
        
    }
    
    private void manageEmployeeSalOrBonusScene(){
        
        TextInputDialog input = new TextInputDialog();
        Font Verdana20 = new Font("Verdana",20);
        
        BorderPane MainPane = new BorderPane();
        
        HBox TopPane = new HBox();
        Label ManageSalLabel = new Label("Manage an employee's salary or bonus");
        TopPane.getChildren().add(ManageSalLabel);
        TopPane.setAlignment(Pos.CENTER);
        
        GridPane CenterPane = new GridPane();
        CenterPane.setHgap(20);
        CenterPane.setVgap(20);
        CenterPane.setAlignment(Pos.CENTER);
        
        Label EmpIDLabel = new Label("Employee ID: ");
        EmpIDLabel.setFont(Font.font("Verdana",FontWeight.SEMI_BOLD,15));
        CenterPane.add(EmpIDLabel,0,0);
        
        Label hint = new Label("Use this ID for TESTing: 1234567890");
        hint.setFont(Font.font("Times New Roman",30));
        hint.setTextFill(Color.RED);
        CenterPane.add(hint, 2, 1);
        
        TextField EmpIDField = new TextField("");
        EmpIDField.setFont(Font.font("Times New Roman",FontWeight.MEDIUM,15));
        CenterPane.add(EmpIDField, 1, 0);
        
        Button ClearButton = new Button("Clear ID field");
        ClearButton.setFont(Verdana20);
        ClearButton.setTextFill(Color.RED);
        CenterPane.add(ClearButton, 2, 0);
        
        Button IncSalButton = new Button("Increment Salary");
        IncSalButton.setFont(Verdana20);
        IncSalButton.setTextFill(Color.GREENYELLOW);
        CenterPane.add(IncSalButton, 1, 1);
        
        Button SetBnsButton = new Button("Add incentive");
        SetBnsButton.setFont(Verdana20);
        SetBnsButton.setTextFill(Color.GREEN);
        CenterPane.add(SetBnsButton, 1, 2);
        
        Button GetBnsButton = new Button("Retrieve incentive");
        GetBnsButton.setFont(Verdana20);
        GetBnsButton.setTextFill(Color.GREEN);
        CenterPane.add(GetBnsButton, 2, 2);
        
        Button GenPayChkButton = new Button("Generate Monthly Paycheck");
        GenPayChkButton.setFont(Verdana20);
        CenterPane.add(GenPayChkButton, 1, 3);
        
        Button PrevMenuButton = new Button("Go back");
        PrevMenuButton.setFont(Verdana20);
        PrevMenuButton.setTextFill(Color.RED);
        CenterPane.add(PrevMenuButton, 2, 4);
        
        MainPane.setCenter(CenterPane);
        MainPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Scene MgEmpSalRBnsScene = new Scene(MainPane,width,height);
        primaryStage.setScene(MgEmpSalRBnsScene);
        primaryStage.show();
        
        ClearButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                EmpIDField.clear();
            }
        
        
        });
        
        IncSalButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            String EmpName;
            ResultSet rs1,rs2,rs3;
            int EmpSal;
            boolean result;
            @Override
            public void handle(MouseEvent event) {
                
                EmpName = null;
                rs1 = rs2 = rs3 = null;
                result = false;
                EmpSal = 0;
                EmpName = null;                            
                if(EmpIDField.getText().compareTo("")==0){
                    //Generate empty input field alert 
                    alert.setAlertType(AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Empty input error");
                    alert.setContentText("Employee ID field cannot be empty!!!");
                    alert.showAndWait();
                }
                else{
                    dbConnector.openConnection();
                    rs1 = dbConnector.executeSelectQuery("SELECT EMP_SALARY FROM EMPLOYEE_PAYROLL WHERE EMP_ID = "+Integer.valueOf(EmpIDField.getText()));
                    rs2 = dbConnector.executeSelectQuery("SELECT EMP_FNAME,EMP_LNAME FROM EMPLOYEE_DETAILS WHERE EMP_ID = "+Integer.valueOf(EmpIDField.getText()));

                    try{
                        rs1.next();
                        rs2.next();
                        EmpName = rs2.getString("EMP_FNAME")+" "+rs2.getString("EMP_LNAME");
                        EmpSal = rs1.getInt("EMP_SALARY");

                        input.setTitle("Increment salary");
                        input.setHeaderText("Salary increment for " + EmpName);
                        input.setContentText("Current salary is: $"+EmpSal+"\nEnter amount to increment: ");
                        Optional<String> TFresult = input.showAndWait();

                        if (TFresult.isPresent()){

                            EmpSal += Integer.valueOf(TFresult.get());
                            result = dbConnector.executeUpdateQuery("UPDATE EMPLOYEE_PAYROLL SET EMP_SALARY = "+EmpSal+" WHERE EMP_ID = "+EmpIDField.getText());

                            if(result == true){

                                alert.setAlertType(AlertType.INFORMATION);
                                alert.setTitle("Status");
                                alert.setHeaderText("SUCCESS!!");
                                alert.setContentText("Salary incremented successfully");
                                alert.showAndWait();
                            }

                            else{

                                alert.setAlertType(AlertType.ERROR);
                                alert.setTitle("ERROR!!");
                                alert.setHeaderText("Unknown Error");
                                alert.setContentText("Error occurred. Please try again");
                                alert.showAndWait();
                            }

                        }

                        else{

                            alert.setAlertType(AlertType.ERROR);
                            alert.setTitle("ERROR!!");
                            alert.setHeaderText("Empty argument!!");
                            alert.setContentText("Enter a value to increment or press cancel button");
                            alert.showAndWait();

                        }


                    }
                    catch(Exception e){

                        System.err.println("Error in salary increment module!!!");

                        e.printStackTrace();
                    }
                    dbConnector.closeConnection();
                }
            }
        });
        
        SetBnsButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            ResultSet rs1,rs2,rs3;
            String EmpName;
            int Incentive;
            boolean result;
            @Override
            public void handle(MouseEvent event) {
                
                if(EmpIDField.getText().compareTo("")==0){
                    //Generate empty input field alert 
                    alert.setAlertType(AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Empty input error");
                    alert.setContentText("Employee ID field cannot be empty!!!");
                    alert.showAndWait();
                }
                else{
                    dbConnector.openConnection();
                    rs1 = dbConnector.executeSelectQuery("SELECT EMP_FNAME,EMP_LNAME FROM EMPLOYEE_DETAILS WHERE EMP_ID ="+EmpIDField.getText());
                    rs2 = dbConnector.executeSelectQuery("SELECT EMP_INCENTIVE FROM EMPLOYEE_PAYROLL WHERE EMP_ID ="+EmpIDField.getText());
                    try{
                        if(rs1.next() && rs2.next()){

                            EmpName = rs1.getString("EMP_FNAME")+ " " +rs1.getString("EMP_LNAME");
                            Incentive = rs2.getInt("EMP_INCENTIVE");
                            input.setTitle("Set/add incentive");
                            input.setHeaderText("Add incentive for " +EmpName);
                            input.setContentText("Current incentive is: $" +Incentive+ "\nEnter amount to increment: ");
                            Optional<String> TFresult = input.showAndWait();

                            if(TFresult.isPresent()){

                                Incentive += Integer.valueOf(TFresult.get());
                                result = dbConnector.executeUpdateQuery("UPDATE EMPLOYEE_PAYROLL SET EMP_INCENTIVE = "+Incentive+" WHERE EMP_ID = "+EmpIDField.getText());
                                if(result == true){

                                    //Generate success info alert
                                    alert.setAlertType(AlertType.INFORMATION);
                                    alert.setTitle("Status");
                                    alert.setHeaderText("Success!!");
                                    alert.setContentText("Successfully incremented");
                                    alert.showAndWait();
                                }
                                else{

                                    //Generate error alert
                                    alert.setAlertType(AlertType.ERROR);
                                    alert.setTitle("Error");
                                    alert.setHeaderText("Error!!");
                                    alert.setContentText("Error updating incentive. Please try again.");
                                    alert.showAndWait();
                                }

                            }
                            else{

                                //Generate empty argument error
                                alert.setAlertType(AlertType.ERROR);
                                alert.setTitle("Error");
                                alert.setHeaderText("Empty argument!!");
                                alert.setContentText("ID Field cannot be empty");
                                alert.showAndWait();
                            }
                        }

                        else{

                            //Generate ID invalid alert
                            alert.setAlertType(AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setHeaderText("Error!!");
                            alert.setContentText("ID is invalid. Enter again");
                            alert.showAndWait();
                        }
                    }

                    catch(SQLException sqle){

                        System.err.println("Exception in Set Bonus button handling");
                        sqle.printStackTrace();
                    }
                    rs1 = rs2 = rs3 = null;
                    EmpName = null;
                    Incentive = 0;
                    dbConnector.closeConnection();
                }
            }
        });
        
        GetBnsButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            int bns;
            String EmpName;
            ResultSet rs1,rs2;
            
            @Override
            public void handle(MouseEvent event) {
                
                if(EmpIDField.getText().compareTo("") == 0){
                    //Generate error alert
                    alert.setAlertType(AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("ID field Empty");
                    alert.setContentText("Employee ID field cannot be empty");
                    alert.showAndWait();
                }
                else{
                    try{
                        
                        dbConnector.openConnection();
                        rs1 = dbConnector.executeSelectQuery("SELECT EMP_FNAME, EMP_LNAME FROM EMPLOYEE_DETAILS WHERE EMP_ID="+EmpIDField.getText());
                        rs2 = dbConnector.executeSelectQuery("SELECT EMP_INCENTIVE FROM EMPLOYEE_PAYROLL WHERE EMP_ID="+EmpIDField.getText());
                        if(rs1.next()&&rs2.next()){
                            EmpName = rs1.getString("EMP_FNAME")+" "+rs1.getString("EMP_LNAME");
                            bns = rs2.getInt("EMP_INCENTIVE");
                            alert.setAlertType(AlertType.INFORMATION);
                            alert.setTitle("Incentive Info");
                            alert.setHeaderText("The current incentive for "+EmpName);
                            alert.setContentText("Incentive is: $"+bns);
                            alert.showAndWait();
                        }
                        else{
                            //generate invalid ID error
                            alert.setAlertType(AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setHeaderText("Invalid Employee ID");
                            alert.setContentText("The employee ID does not exist");
                            alert.showAndWait();
                        }
                    }
                    catch(SQLException sqle){
                        System.err.println("Database error in Get Bonus action handler module");
                        sqle.printStackTrace();
                    }
                    
                    bns = 0;
                    EmpName = null;
                    rs1 = rs2 = null;
                    dbConnector.closeConnection();
                }   
            }
        });
        
        GenPayChkButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

            ResultSet rs1,rs2;
            String EmpName;
            int sal;
            @Override
            public void handle(MouseEvent event) {
                System.out.println("inside handler of Pay check");
                if(EmpIDField.getText().compareTo("")==0){
                    //Generate empty input field alert 
                    alert.setAlertType(AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Empty input error");
                    alert.setContentText("Employe ID field cannot be empty!!!");
                    alert.showAndWait();
                }
                
                else{
                    dbConnector.openConnection();
                    try{
                        rs1 = dbConnector.executeSelectQuery("SELECT EMP_FNAME,EMP_LNAME FROM EMPLOYEE_DETAILS WHERE EMP_ID ="+EmpIDField.getText());
                        System.out.println("\ninside try1");
                        
                        if(rs1.next()){
                            
                            System.out.println("rs1 retrieved");
                            System.out.println("\nresult retrieved from DB");
                            EmpName = rs1.getString("EMP_FNAME")+" "+rs1.getString("EMP_LNAME");
                            System.out.println(EmpName);
                        }
                    }
                    catch(SQLException sqle){
                        System.err.println("Error in 1st try-catch block of cheque generator module..");
                        sqle.printStackTrace();
                    }
                    dbConnector.closeConnection();
                    dbConnector.openConnection();
                    
                    try{
                        
                        rs2 = dbConnector.executeSelectQuery("SELECT EMP_SALARY,EMP_INCENTIVE FROM EMPLOYEE_PAYROLL WHERE EMP_ID ="+EmpIDField.getText());
                        if(rs2.next()){
                            System.out.println("rs2 retrieved");
                            sal = Integer.valueOf(rs2.getString("EMP_SALARY"))+Integer.valueOf(rs2.getString("EMP_INCENTIVE"));
                            System.out.println(sal);
                        }
                    }
                    catch(SQLException sqle){
                        System.err.println("Error in 2nd try-catch block of cheque generator module..");
                        sqle.printStackTrace();
                    }
                    if(sal!=0 && EmpName!=null){   
                        alert.setAlertType(AlertType.CONFIRMATION);
                        alert.setTitle("Confirmation");
                        alert.setHeaderText("Confirm the details:");
                        alert.setContentText("Generate cheque for: "+EmpName+"\nAmount to be printed: $"+sal);
                        alert.showAndWait();
                        alert.setAlertType(AlertType.INFORMATION);
                        alert.setTitle("Print Status");
                        alert.setHeaderText("Checque printed");
                        alert.setContentText("Cheque printed successfully. Please collect it.");
                        alert.showAndWait();
                    }
                }
                rs1 = rs2 = null;
                EmpName = null;
                sal = 0;

            }
        });
                
        PrevMenuButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                EmpIDField.clear();
                manageEmpScene();
            }
        });
        
        
    }
    
    private void manageInventoryScene(){
        
        Font Verdana15 = new Font("Verdana",15);
                
        BorderPane MainPane = new BorderPane();
        
        HBox TopPane = new HBox();
        TopPane.setAlignment(Pos.CENTER);
        
        Label DispLabel = new Label("Inventory management page");
        DispLabel.setFont(Font.font("Times New Roman",FontWeight.BOLD,40));
        TopPane.getChildren().add(DispLabel);
        
        MainPane.setCenter(TopPane);
        
        GridPane CenterPane = new GridPane();
                
        Button GetOutOfStockBtn = new Button("Get items OUT OF STOCK");
        GetOutOfStockBtn.setFont(Verdana15);
        CenterPane.add(GetOutOfStockBtn, 0, 0);
        
        Button GetLowStockBtn = new Button("Get items LOW IN STOCK");
        GetLowStockBtn.setFont(Verdana15);
        CenterPane.add(GetLowStockBtn, 0, 1);
        
        Button PlaceOrderBtn = new Button("Place order");
        PlaceOrderBtn.setFont(Verdana15);
        PlaceOrderBtn.setTextFill(Color.GREENYELLOW);
        CenterPane.add(PlaceOrderBtn, 0, 2);
        
        Button GoBackBtn = new Button("Go back to Manager tools");
        GoBackBtn.setFont(Verdana15);
        GoBackBtn.setTextFill(Color.RED);
        CenterPane.add(GoBackBtn, 1, 3);
        
        Button LogoutBtn = new Button("Logout");
        LogoutBtn.setTextFill(Color.CRIMSON);
        CenterPane.add(LogoutBtn, 1, 4);
        
        CenterPane.setAlignment(Pos.CENTER);
        CenterPane.setHgap(20);
        CenterPane.setVgap(20);
        
        MainPane.setCenter(CenterPane);
        MainPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Scene MgInvntryScene = new Scene(MainPane,width,height);
        primaryStage.setScene(MgInvntryScene);
        primaryStage.show();
        
        LogoutBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                loginScene();
            }
        
        
        });
        GoBackBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
                managerTools();
            }
        
        
        });
        
        GetOutOfStockBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            ResultSet rs;
            String items;
            @Override
            public void handle(MouseEvent event) {
                
                try{
                    dbConnector.openConnection();
                    rs = dbConnector.executeSelectQuery("SELECT ITEM_NAME FROM STORE_INVENTORY WHERE ITEM_QTY=0");
                    items = "";
                    
                    while(rs.next()){
                        items += rs.getString("ITEM_NAME")+" , ";
                        
                    }
                    if(items.compareTo("") == 0){
                        alert.setAlertType(AlertType.INFORMATION);
                        alert.setTitle("Out of stock list");
                        alert.setHeaderText("Items out of stock");
                        alert.setContentText("No item(s) is/are currently out of stock. Check later.");
                        alert.showAndWait();
                    }
                    else{
                        items = items.substring(0,items.length()-4);
                        alert.setAlertType(AlertType.INFORMATION);
                        alert.setTitle("Out of Stock list");
                        alert.setHeaderText("Items out of stock");
                        alert.setContentText(items);
                        alert.showAndWait();
                    }
                }
                catch(SQLException sqle){
                    //Generate database connection error
                    System.err.println("Database error in get out of stock action handler module");
                    sqle.printStackTrace();
                }
                dbConnector.closeConnection();
            }
        });
        
        GetLowStockBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            String items;
            ResultSet rs;
            
            @Override
            public void handle(MouseEvent event) {
                try{
                    dbConnector.openConnection();
                    rs = dbConnector.executeSelectQuery("SELECT ITEM_NAME FROM STORE_INVENTORY WHERE ITEM_QTY<=5");
                    items = "";
                    
                    while(rs.next()){
                        items += rs.getString("ITEM_NAME")+" , ";
                        
                    }
                    if(items.compareTo("") == 0){
                        alert.setAlertType(AlertType.INFORMATION);
                        alert.setTitle("Items low in stock");
                        alert.setHeaderText("List of items low in stock");
                        alert.setContentText("No item(s) is/are currently low in stock. Check later.");
                        alert.showAndWait();
                    }
                    else{
                        items = items.substring(0,items.length()-4);
                        alert.setAlertType(AlertType.INFORMATION);
                        alert.setTitle("Out of Stock list");
                        alert.setHeaderText("Items out of stock");
                        alert.setContentText(items);
                        alert.showAndWait();
                    }
                }
                catch(SQLException sqle){
                    System.err.println("Exception in Get low stock action handler module");
                    sqle.printStackTrace();
                }
            }
        });
        
        PlaceOrderBtn.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent event) {
                
            }
        });
    }
    
    public static void main(String[] args){
        
        launch(args);
    }
}
