/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Terminals;


import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author Bharath
 */
public class SelfCheckoutTerminal extends Application {
    
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    double width = screenSize.getWidth()-40;
    double height = screenSize.getHeight()-120;
    
    Font font1 = new Font("Courier",14);
    private final boolean flag = false;
    String ID;
    String cfname,clname;
    int crpts;
    double TTLCost = 0;
    Stage primaryStage;
    Scene LoginScene, Billing, PaymentScene, CardPayment, CashPayment, RedeemPoints;
    Label CnameLabel,CptsLabel,BillLabel;
    Alert alert = new Alert(AlertType.ERROR);
    AccessConnector db = new AccessConnector();
    
    //advertisements for the market
    Timeline mAds;
    
    //advertisements for the cards
    Timeline cAds;
    
    //add advertisement images here
    Image mimg1 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad1.jpg");
    
    Image mimg2 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad2.jpg");
    
    Image mimg3 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad3.jpg");
    
    Image mimg4 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad4.jpg");
    
    Image mimg5 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad5.jpg");
    
    Image mimg6 = new Image("File:\\D:\\ApplicationPics\\marketAd\\ad6.jpg");
    
    ImageView mAdvw = new ImageView();
    
    @Override
    public void start(Stage stage) {
        
        primaryStage = stage;
        //Purchasing starts with login of customer
        login();
        primaryStage.setTitle("Self check-in terminal");
        primaryStage.setScene(LoginScene);
        primaryStage.show();
        
    }
    
    private void login(){
        
        //Resetting the variables
        TTLCost = 0;
        
        BorderPane MainLoginPane = new BorderPane();
        
        LoginScene = new Scene(MainLoginPane,width,height);
        HBox ads = new HBox(mAdvw);
        ads.setAlignment(Pos.CENTER);
        mAds = new Timeline(new KeyFrame(Duration.seconds(3), new EventHandler<ActionEvent>() {
            
            //set counter
            int counter = 1;
            //set image count
            int count = 6;

            @Override
            public void handle(ActionEvent event) {

                System.out.println("Displaying market ad"+counter);
                switch(counter){
                    case 1:
                        mAdvw.setImage(mimg1);
                        break;
                    case 2:
                        mAdvw.setImage(mimg2);
                        break;
                    case 3:
                        mAdvw.setImage(mimg3);
                        break;
                    case 4:
                        mAdvw.setImage(mimg4);
                        break;
                    case 5:
                        mAdvw.setImage(mimg5);
                        break;
                    case 6:
                        mAdvw.setImage(mimg6);
                        break;
                    default:
                        System.out.println("Erroneous switch value for market ad!!\n"+counter);
                }
                
                if (counter == count)
                    counter = 1;
                else
                    counter++;
                MainLoginPane.setBottom(ads);
            }
        }));
        mAds.setCycleCount(Timeline.INDEFINITE);
        mAds.play();
        
        GridPane CenterPane = new GridPane();
        
        //Start inserting widgets
        //Instructional label
        Label LoginLabel = new Label("Login with your customer ID:");
        LoginLabel.setFont(Font.font("Courier", FontWeight.SEMI_BOLD, 20));
        
        //Where the customer enters his/her ID to login
        TextField CustomerIDTextField = new TextField("1234567890");
        CustomerIDTextField.setFont(font1);
        CustomerIDTextField.setAlignment(Pos.CENTER_LEFT);
        
        //Button to login
        Button LoginButton = new Button("Login");
        LoginButton.setAlignment(Pos.CENTER);
        LoginButton.setFont(font1);
        
        //Add the widgets to sub-gridpane
        CenterPane.add(LoginLabel, 0, 0);
        CenterPane.add(CustomerIDTextField, 1, 1);
        CenterPane.add(LoginButton, 2, 1);
        CenterPane.setPadding(new Insets(25,25,25,25));
        CenterPane.setAlignment(Pos.CENTER);
        CenterPane.setHgap(10);
        CenterPane.setVgap(10);
        
        //Add the sub-gridpane to center of main-pane
        MainLoginPane.setCenter(CenterPane);
        MainLoginPane.setPadding(new Insets(25,25,25,25));
        MainLoginPane.setPrefSize(width, height);
        
        //Create and add a label to the top of main-pane
        Label WelcomeLabel = new Label("Welcome To Kwik-E-Mart");
        WelcomeLabel.setFont(Font.font("Courier",FontWeight.EXTRA_BOLD,30));
        WelcomeLabel.setTextFill(Color.DARKGREEN);
        WelcomeLabel.setAlignment(Pos.CENTER);
        HBox wbox = new HBox(WelcomeLabel);
        wbox.setAlignment(Pos.CENTER);
        MainLoginPane.setTop(wbox);
        MainLoginPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        Label info = new Label("You can find it at the\nback of your membership card\nas shown here:");
        info.setFont(Font.font("Courier", FontWeight.BOLD, 20));
        
        Image img1 = new Image("file:\\D:\\ApplicationPics\\Membershipcard.jpg");
        
        ImageView imgvw = new ImageView(img1);
        CenterPane.add(info,0,2);
        CenterPane.add(imgvw,0,3);
                
        //Create handlers for clicking the login button
        LoginButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            ResultSet result;
            
            @Override
            public void handle(MouseEvent event) {
                
                //When the mouse is clicked, the database is queried with the ID for validity
                ID = null;
                ID = CustomerIDTextField.getText();
                
                //Preliminary checks
                if(ID.isEmpty()){
                    
                    //Generate "ID field is empty!!" Alert
                    alert.setAlertType(AlertType.ERROR);
                    alert.setHeaderText("ERROR!!");
                    alert.setContentText("ID field is empty!!");
                    alert.showAndWait();
                }
                
                else if(ID.length() < 10 || ID.length() > 10){
                    
                    //Generate "The ID length should be no more than 10 numbers and no less than 10 numbers" alert
                    alert.setAlertType(AlertType.ERROR);
                    alert.setHeaderText("ERROR!!");
                    alert.setContentText("ID length should be exactly 10");
                    alert.showAndWait();
                    //Empty the CustomerIDTextField
                    CustomerIDTextField.clear();
                }
                
                else{
                    
                    //validate by querying with the database
                    db.openConnection();
                    
                    try{
                        if(db.isOpen() == true)
                        {   
                            
                            cfname = null;
                            clname = null;                            
                            crpts = 0;
                            result = null;
                            result = db.executeSelectQuery("SELECT CUST_FNAME, CUST_LNAME, CUST_RWDPTS FROM CUSTOMER_DETAILS WHERE CUST_ID="+ID);
                            if(result != null){
                                
                                //proceed to billing
                                mAds.pause();
                                billing();
                                cfname = result.getString("CUST_FNAME");
                                clname = result.getString("CUST_LNAME");
                                CnameLabel.setText("WELCOME!!\n\nName: "+cfname+" "+clname);
                                crpts = result.getInt("CUST_RWDPTS");
                                CptsLabel.setText("\nYour current\nreward points: "+crpts);
                                CptsLabel.setFont(Font.font("Courier",FontWeight.BOLD,14));
                                CnameLabel.setFont(Font.font("Courier",FontWeight.SEMI_BOLD,14));
                                primaryStage.setScene(Billing);
                                CustomerIDTextField.clear();
                            }
                            else{
                                
                                //Generate "invalid ID" error
                                alert.setAlertType(AlertType.ERROR);
                                alert.setHeaderText("ERROR");
                                alert.setContentText("Customer ID does not exist!!");
                                alert.showAndWait();
                                CustomerIDTextField.clear();
                            }
                            db.closeConnection();
                        }
                        
                    }
                    catch(SQLException sqle){
                        
                        sqle.printStackTrace();
                        //Generate "Error" Alert
                        alert.setAlertType(AlertType.ERROR);
                        alert.setHeaderText("ERROR");
                        alert.setContentText("Querying error!!\nTry again!!");
                        db.closeConnection();
                    }
                }
            }
            
        });

    }
    
    private void billing(){
        
        //Billing widgets
        CnameLabel = new Label("Name: "+cfname+" "+clname);        
        CptsLabel = new Label("Reward Points: "+Integer.toString(crpts));
        
        BillLabel = new Label("SNo.  ITEM_NAME\tITEM_COST\n");
        BillLabel.setAlignment(Pos.TOP_CENTER);
        BillLabel.setFont(Font.font("OCR-A", FontWeight.BOLD, 12));
        ScrollPane sp = new ScrollPane();
        sp.setContent(BillLabel);
        sp.setPrefHeight(250);
        sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        sp.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        
        Label ItemIDLabel = new Label("Enter Item ID: ");
        TextField ItemIDTextField = new TextField("12345");
        ItemIDTextField.setAlignment(Pos.CENTER_LEFT);
        Button AddItemButton = new Button("Add Item",new ImageView(new Image("file:\\D:\\ApplicationPics\\Icons\\AddItem.png")));
        AddItemButton.setAlignment(Pos.CENTER);
        GridPane BillingPane = new GridPane();
        Label BillLabelDesc = new Label("Billed Items:");
        Label BillingLabelDescr = new Label("Billing page");
        BillingLabelDescr.setFont(Font.font("Courier",FontWeight.BOLD,20));
        BillingLabelDescr.setAlignment(Pos.CENTER_LEFT);
        BillingPane.setAlignment(Pos.CENTER);
        BillingPane.setHgap(20);
        BillingPane.setVgap(20);
        BillingPane.add(BillLabelDesc, 0, 2);
        BillingPane.add(sp, 0, 3, 1, 4);
        BillingPane.add(ItemIDLabel, 1, 3);
        BillingPane.add(ItemIDTextField, 1, 4);
        BillingPane.add(AddItemButton, 1, 5);
        
        BorderPane MainBillingPane = new BorderPane();
        MainBillingPane.setCenter(BillingPane);
        MainBillingPane.setTop(BillingLabelDescr);
        MainBillingPane.setPadding(new Insets(25, 25, 25, 25));        
        Button PaymentButton = new Button("Proceed to payment");
        PaymentButton.setStyle(
                "-fx-background-radius: 5em; " +
                "-fx-min-width: 150px; " +
                "-fx-min-height: 100px; " +
                "-fx-max-width: 170px; " +
                "-fx-max-height: 100px;" + 
                "-fx-background-color: red; "+
                "-fx-effect: dropshadow( one-pass-box , black , 8 , 0.0 , 2 , 0 ); " +
                "-fx-font: 15 arial; " +
                "-fx-font-weight: bold;"
        );
        
        BillingPane.add(PaymentButton,1,6);
        
        VBox cust_details = new VBox();
        cust_details.setAlignment(Pos.TOP_LEFT);
        cust_details.getChildren().add(CnameLabel);
        cust_details.getChildren().add(CptsLabel);
        cust_details.setPadding(new Insets(25,25,25,25));
        
        MainBillingPane.setRight(cust_details);
        Billing = new Scene(MainBillingPane,width,height);
        MainBillingPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        BillLabel.setBackground(new Background(new BackgroundFill(Color.WHITE,CornerRadii.EMPTY,Insets.EMPTY)));
        
        //Action when user enters the item ID and presses the AddItemButton
        AddItemButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            long ItemID = 0;
            String ItemName;
            double ItemCost = 0;
            String temp = null; 
            int count = 0;
            StringBuilder sb = null;
            ResultSet rs = null;
            
            @Override
            public void handle(MouseEvent event) {
                
                ItemID = Long.valueOf(ItemIDTextField.getText());
                //Query the database for item using ItemID
                db.openConnection();
                
                try{
                    if(db.isOpen() == true){
                        
                        rs = db.executeSelectQuery("SELECT ITEM_NAME, ITEM_COST FROM STORE_INVENTORY WHERE ITEM_ID="+ItemID);
                        //Check if the query returned anything
                        if(rs != null){
                            
                            //Item exists
                            ItemName = rs.getString("ITEM_NAME");
                            ItemCost = Double.valueOf(rs.getString("ITEM_COST"));
                            TTLCost += ItemCost; 
                            temp = BillLabel.getText();
                            sb = new StringBuilder(temp);
                            
                            if(count > 0){                                
                                sb.delete(temp.indexOf("\n\nTOTAL:\t\t\t"),temp.length());
                            }
                            sb.append("\n"+(++count)+".\t"+ItemName+"\t"+ItemCost);
                            sb.append("\n\nTOTAL:\t\t\t"+String.format("%.2f",TTLCost));
                            BillLabel.setText(sb.toString());
                            sb = null;
                        }
                        
                        else{
                            
                            //Generate "Item not found" error
                            alert.setContentText("Invalid item ID!!!");
                            alert.setHeaderText("ERROR");
                            alert.showAndWait();
                        }
                    }
                }
                catch(SQLException sqle){
                    
                    sqle.printStackTrace();
                }
            }
        });
        
        PaymentButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
        
            @Override
            public void handle(MouseEvent event) {
                
                alert.setAlertType(AlertType.CONFIRMATION);
                alert.setHeaderText("Confirm action");
                alert.setContentText("Are you sure you have billed all of your items?\nPress OK button to pay the total cost");
                
                Optional<ButtonType> result = alert.showAndWait();
                    if (result.get() == ButtonType.OK){
                        
                        // ... user chose OK
                        //Proceed with payment
                        payment();
                        primaryStage.setScene(PaymentScene);
                        BillLabel.setText("");
                        ItemIDTextField.setText("");
                    } else {
                    
                    // ... user chose CANCEL or closed the dialog
                    
                    }
            
            }
        
        });
    }
    
    private void payment(){
        
        Label BillLabel = new Label(String.format("%.2f", TTLCost));
        
        GridPane PaymentPane = new GridPane();
        PaymentPane.setAlignment(Pos.CENTER);
        PaymentPane.setHgap(20);
        PaymentPane.setVgap(20);
        PaymentPane.setPadding(new Insets(25,25,25,25));
        
        //Creating payment widgets
        Button PayWithDebitCardButton = new Button("Pay with DebitCard",new ImageView(new Image("file:\\D:\\ApplicationPics\\Icons\\CreditCard.png")));
        Button PayWithCashButton = new Button("Pay with Cash",new ImageView(new Image("file:\\D:\\ApplicationPics\\Icons\\cash2.png")));
        Button RedeemPointsButton = new Button("Redeem reward points",new ImageView(new Image("file:\\D:\\ApplicationPics\\Icons\\reward points.png")));
        Label PaymentOptionsLabelButton = new Label("Choose one of the below options:");  
        
        //Adding the widgets to the pane
        PaymentPane.add(PaymentOptionsLabelButton,0,1);
        PaymentPane.add(BillLabel,0,2);
        PaymentPane.add(PayWithDebitCardButton,0,3);
        PaymentPane.add(PayWithCashButton,0,4);
        PaymentPane.add(RedeemPointsButton,0,5);
        
        BorderPane MainPaymentPane = new BorderPane();
        MainPaymentPane.setCenter(PaymentPane);
        MainPaymentPane.setBackground(new Background(new BackgroundFill(Color.BURLYWOOD,CornerRadii.EMPTY,Insets.EMPTY)));
        
        PaymentScene = new Scene(MainPaymentPane,width,height);
        
        //Creating debit card payment widgets
        GridPane SubCardPane = new GridPane();
        SubCardPane.setHgap(10);
        SubCardPane.setVgap(10);
        SubCardPane.setAlignment(Pos.CENTER);
        BorderPane CardPane = new BorderPane();
        
        Font TNRFont = Font.font("Times New Roman",FontWeight.BOLD,18);
        
        Label SecureDispLabel = new Label("SECURE Gateway");        
        SecureDispLabel.setFont(Font.font("Verdana",FontWeight.BOLD,40));
        SecureDispLabel.setAlignment(Pos.CENTER);
        SecureDispLabel.setTextFill(Color.GREEN);
        HBox pbox = new HBox(SecureDispLabel);
        pbox.setAlignment(Pos.CENTER);
        CardPane.setTop(pbox);
                
        Label CardNumberLabel = new Label("Card number: ");
        CardNumberLabel.setFont(TNRFont);
        SubCardPane.add(CardNumberLabel, 0, 0);
        
        TextField CardNumberTextField = new TextField("123457890123456");
        CardNumberTextField.setFont(Font.font("Verdana"));
        SubCardPane.add(CardNumberTextField, 1, 0);
                        
        Label dobLabel = new Label("Card expires on: ");
        dobLabel.setFont(TNRFont);
        SubCardPane.add(dobLabel, 0, 1);
        
        DatePicker dob = new DatePicker();
        SubCardPane.add(dob, 1, 1);
        
        Label CardHolderName = new Label("Card Holder's name:");
        CardHolderName.setFont(TNRFont);
        SubCardPane.add(CardHolderName, 0, 2);
        
        TextField CardHolderNameField = new TextField("ALEX VAUSSE");
        SubCardPane.add(CardHolderNameField, 1, 2);
        
        Label BalanceLabel = new Label("Balance amount: ");
        SubCardPane.add(BalanceLabel, 0, 3);
        
        SubCardPane.add(BillLabel, 1, 3);
        
        Button MakeCardPaymentButton = new Button("Make payment");
        SubCardPane.add(MakeCardPaymentButton,1,4);
        
        CardPane.setCenter(SubCardPane);
        SubCardPane.setHgap(10);
        SubCardPane.setVgap(10);
        
        Image secure = new Image("File:\\D:\\ApplicationPics\\Secure_Page_Logo2.jpg");
        ImageView securevw = new ImageView(secure);
        SubCardPane.add(securevw, 2, 0);

        Scene DebitCardScene = new Scene(CardPane,width,height);
        
        Image card = new Image("File:\\D:\\ApplicationPics\\Credit_Card_Logo.jpg");        
        ImageView cardvw = new ImageView(card);
        cardvw.setScaleX(0.25);
        cardvw.setScaleY(0.25);
        cardvw.preserveRatioProperty();
        CardPane.setBottom(cardvw);
        
        PayWithDebitCardButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
        
            @Override
            public void handle(MouseEvent event) {
                
                primaryStage.setScene(DebitCardScene);
            }
        });
        
        MakeCardPaymentButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            @Override
            public void handle(MouseEvent event) {
                
                alert.setAlertType(AlertType.INFORMATION);
                alert.setContentText("Payment successful!!!\nCollect your receipt");
                alert.showAndWait();
                primaryStage.setScene(LoginScene);
            }
        });
                
        PayWithCashButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
            
            @Override
            public void handle(MouseEvent event) {
                
                
                alert.setAlertType(AlertType.INFORMATION);
                alert.setHeaderText("INSERT CASH");
                alert.setContentText("Begin inserting cash into the machine");
                alert.showAndWait();
                
                alert.setHeaderText("Success!!");
                alert.setContentText("Payment successfull!!");
                alert.showAndWait();
                primaryStage.setScene(LoginScene);
                
            }
        });
    }
    
    //Advertisement displayed in various panes
    private void marketAds(){
        

        
        //code to play it
        //mAds.play();
    }
    
    //Advertisements displayed in the payment page
    private void cardAds(){
        
        //add advertisement images here
        
        cAds = new Timeline(new KeyFrame(Duration.seconds(5), new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
            
                System.out.println("This is called every 5 seconds on UI thread");
            }
        }));
        cAds.setCycleCount(Timeline.INDEFINITE);
        
        //code to play it
        //cAds.play();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}