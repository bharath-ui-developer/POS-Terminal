Cufon.replace('h3, h4, h5, .menu > li > a, .list-2 a, .title-3, .title-4, .title-5, .tdate-1', { fontFamily: 'Duality', hover:true });
Cufon.replace('.title-1, .title-2', { fontFamily: 'Century Gothic', hover:true });
Cufon.replace('.link-1, .link-2', { fontFamily: 'Lobster', hover:true });
Cufon.replace('.footer-row strong', { fontFamily: 'RomanSerif', hover:true });